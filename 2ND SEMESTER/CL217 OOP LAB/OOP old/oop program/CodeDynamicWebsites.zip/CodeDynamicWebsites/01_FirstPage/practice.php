<!DOCTYPE html>
<html>
	<head>
		<title>My First PHP Web Page</title>
	</head>
	<body>
		<?php print('Hello friends!'); ?>
	</body>
</html>
