#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <string.h>

// Debugging Functions
void debug(char*, int);

// Data Structure
struct Laptop {
	char purpose[10], company[10], os[20], processor[20], gc[5];
	int size, hd, ram, ssd, battery_life, price;
};

// Helper Functions
int nextValue(FILE*);
char* getPurpose(int);
char* getCompany(int);
char* getOS(int);
char* getProcessor(int);
int getHD(int);
int getSSD(int);
int getRAM(int);
int getBT(int);
int getSize(int);
char* getGC(int);
char* toString(int);
struct Laptop populateData(FILE*);
struct Laptop defaultFilter(void);
void printLaptopInfo(struct Laptop*, int);
void printFilteredlaptops(struct Laptop*, struct Laptop, int);
int getFilteredLaptopCount(struct Laptop*, struct Laptop, int);

// Menu Display Functions
void mainMenu(struct Laptop*, struct Laptop, int);
void purposeMenu(void);
void companyMenu(void);
void osMenu(void);
void sizeMenu(void);
void processorMenu(void);
void hdMenu(void);
void ramMenu(void);
void ssdMenu(void);
void gcMenu(void);
void btMenu(void);
void invalidUserInput(void);

int main() {
	FILE* db = fopen ("data.txt", "r");
//	FILE* output = fopen ("output.txt", "w");
	if( db==NULL ) {
		printf("Cannot open file!");
		return 1;
	}

	int db_size = nextValue(db);
	struct Laptop laptops[db_size];		

	int db_row;
	for( db_row=0; db_row<db_size; db_row++ )
		laptops[db_row] = populateData(db);
	fclose(db);

	struct Laptop filter = defaultFilter();

	int user_input = -1;
	int input_type = 1;
	mainMenu(laptops, filter, db_size);
	while( user_input!=0 ) {
		if( user_input!=11 )	
			scanf("%d", &user_input);
		else
			user_input++;
		user_input *= input_type;
		switch( user_input ) {
			case 12:
				mainMenu(laptops, filter, db_size);
				break;
			
			case 9000000000:// Back to Main Menu
			case 900000000:// Back to Main Menu
			case 90000000:// Back to Main Menu
			case 9000000: //Back to Main Menu
			case 900000:// Back to Main Menu
			case 90000:// Back to Main Menu
			case 9000:// Back to Main Menu
			case 900:// Back to Main Menu
			case 90:// Back to Main Menu
				input_type = 1;
				mainMenu(laptops, filter, db_size);
				break;
			
			case 1:// Show All Laptops
				printFilteredlaptops(laptops, filter, db_size);
				getch();
				mainMenu(laptops, filter, db_size);
				input_type=1;
				break;
				
			case 2:// Filter By Purpose
				purposeMenu();
				input_type=10;
				break;
				
			case 10:// Filter By Purpose->Game
			case 20:// Filter By Purpose->Program
			case 30:// Filter By Purpose->Office
			case 40:// Filter By Purpose->Home
				strcpy(filter.purpose,getPurpose(((user_input/input_type)-1)) );
				mainMenu(laptops, filter, db_size);
				input_type = 1;
				break;
			case 80:// Clear Filter
				strcpy(filter.purpose,"");
				mainMenu(laptops, filter, db_size);
				input_type = 1;
				break;
			
			case 120:
				purposeMenu();
				break;
				
			case 3:// Filter By Company
				companyMenu();
				input_type=100;
				break;
				
			case 100:// Filter By Company->ASUS
			case 200:// Filter By Company->HP
			case 300:// Filter By Company->DELL
			case 400:// Filter By Company->APPLE
				strcpy(filter.company,getCompany(((user_input/input_type)-1)) );
				mainMenu(laptops, filter, db_size);
				input_type = 1;
				break;
			case 800:// Clear Filter
				strcpy(filter.company,"");
				mainMenu(laptops, filter, db_size);
				input_type = 1;
				break;
			
			case 1200:
				companyMenu();
				break;
				
			case 4:// Filter By OS
				osMenu();
				input_type=1000;
				break;
				
			case 1000:// Filter By OS->LINUX
			case 2000:// Filter By OS->Windows 8
			case 3000:// Filter By OS->Windows 10
			case 4000:// Filter By OS->MAC OS
				strcpy(filter.os,getOS(((user_input/input_type)-1)) );
				mainMenu(laptops, filter, db_size);
				input_type = 1;
				break;
			case 8000:// Clear Filter
				strcpy(filter.os,"");
				mainMenu(laptops, filter, db_size);
				input_type = 1;
				break;
			
			case 12000:
				osMenu();
				break;
				
			case 5:// Filter By Processor
				processorMenu();
				input_type=10000;
				break;
				
			case 10000:// Filter By Processor->XEON
			case 20000:// Filter By Processor->i5
			case 30000:// Filter By Processor->i7
			case 40000:// Filter By processor->i9
				strcpy(filter.processor,getProcessor(((user_input/input_type)-1)) );
				mainMenu(laptops, filter, db_size);
				input_type = 1;
				break;
			case 80000:// Clear Filter
				strcpy(filter.processor,"");
				mainMenu(laptops, filter, db_size);
				input_type = 1;
				break;
			
			case 120000:
				processorMenu();
				break;
				
			case 6:// Filter By Hard Disk
				hdMenu();
				input_type= 1000000;
				break;
			
			case 1000000: // Filter By Hard Disk -> 500GB
			case 2000000: // FIlter By Hard Disk -> 1000GB
				filter.hd = getHD(((user_input/input_type)-1)) ;
				mainMenu(laptops, filter, db_size);
				input_type = 1;
				break;
				
			case 8000000: // Clear Filter
				filter.hd=0;
				mainMenu(laptops, filter,db_size);
				input_type=1;
				break;
			
			case 12000000:
				hdMenu();
				break;
				
			case 7:// Filter By Graphic Card
				gcMenu();
				input_type=100000;
				break;
				
			case 100000:// Filter By GC->Yes
			case 200000:// Filter By GC->No
				strcpy(filter.gc,getGC(((user_input/input_type)-1)) );
				mainMenu(laptops, filter, db_size);
				input_type = 1;
				break;
			case 800000:// Clear Filter
				strcpy(filter.gc,"");
				mainMenu(laptops, filter, db_size);
				input_type = 1;
				break;
			
			case 1200000:
				gcMenu();
				break;
				
			case 13: // Filter By RAM
				ramMenu();
				input_type = 10000000;
				break;
			case 10000000: // RAM -> 2GB
			case 20000000: // RAM -> 4 GB
			case 30000000: // RAM -> 8 GB
				filter.ram = getRAM(((user_input/input_type)-1));
				mainMenu(laptops, filter, db_size);
				input_type=1;
				break;
				
			case 80000000: // Clear Filter
				filter.ram = 0;
				mainMenu(laptops, filter, db_size);
				input_type=1;
				break;
			case 120000000: 
				ramMenu();
				break;
				
			case 14: // Filter by SSD
				ssdMenu();
				input_type=100000000;
				break;
				
			case 100000000: // SSD -> 0GB
			case 200000000: // SSD -> 64 GB
			case 300000000: // SSD -> 128 GB
				filter.ssd= getSSD(((user_input/input_type)-1));
				mainMenu(laptops, filter, db_size);
				input_type=1;
				break;
				
			case 800000000: // Clear Filter
				filter.ssd = 0;
				mainMenu(laptops, filter, db_size);
				input_type=1;
				break;
			
			case 1200000000:
				ssdMenu();
				break;
				
			
			case 15: // Filter by Battery Life
				btMenu();
				input_type = 1000000000;
				break;
				
			case 1000000000: // Filter by 8 hours
			case 2000000000: // Filter by 16 Hours
				filter.battery_life = getBT(((user_input/input_type)-1));
				mainMenu(laptops, filter, db_size);
				input_type=1;
				break;
				
			case 8000000000:
				filter.battery_life = 0;
				mainMenu(laptops, filter, db_size);
				input_type=1;
				break;
				
			case 12000000000:
				btMenu();
				break;
				
				
			case 16: //Filter by Screen Size
				sizeMenu();
				input_type = 10000000000;
				break;
				
			case 10000000000: // Filter by 12"
			case 20000000000: // Filter by 16"
			case 30000000000: // Filter by 18"
				filter.size = getSize(((user_input/input_type)-1));
				mainMenu(laptops, filter, db_size);
				input_type=1;
				break;
				
			case 80000000000: 
				filter.size = 0;
				mainMenu(laptops, filter, db_size);
				input_type=1;
				break;
				
			case 120000000000:
				sizeMenu();
				break;
			
			case 8:// Clear Filter
				filter = defaultFilter();
				mainMenu(laptops, filter, db_size);
				input_type=1;
				break;
				
			case 0:// Exit Base Function
				break;
				
			default:// Invalid User Input
				user_input = 11;
				invalidUserInput();
		}
	}

//	fclose(output);
	return 0;
}

struct Laptop populateData(FILE* db) {
	struct Laptop laptop;
	strcpy(laptop.purpose, getPurpose(nextValue(db)));
	strcpy(laptop.company, getCompany(nextValue(db)));
	strcpy(laptop.os, getOS(nextValue(db)));
	laptop.size = nextValue(db);
	strcpy(laptop.processor, getProcessor(nextValue(db)));
	laptop.hd = nextValue(db);
	laptop.ram = nextValue(db);
	laptop.ssd = nextValue(db);
	strcpy(laptop.gc, getGC(nextValue(db)));
	laptop.battery_life = nextValue(db);
	laptop.price = nextValue(db);
	return laptop;
}

struct Laptop defaultFilter() {
	struct Laptop laptop;
	strcpy(laptop.purpose, "");
	strcpy(laptop.company, "");
	strcpy(laptop.os, "");
	laptop.size = 0;
	strcpy(laptop.processor, "");
	laptop.hd = 0;
	laptop.ram = 0;
	laptop.ssd = 0;
	strcpy(laptop.gc, "");
	laptop.battery_life = 0;
	laptop.price = 0;
	return laptop;
}

void printFilteredlaptops(struct Laptop* laptops, struct Laptop filter, int total) {
	int index=0, count=0; 
	int printLaptop = 0;
	struct Laptop filtered_laptops[total];
	for(index; index<total; index++) {
		printLaptop = 1;
		
		if( strcmp(filter.purpose,"")!=0 && strcmp(filter.purpose, laptops[index].purpose) !=0 )
			printLaptop = 0;			

		if( strcmp(filter.company,"")!=0 && strcmp(filter.company, laptops[index].company) !=0 )
			printLaptop = 0;

		if( strcmp(filter.os,"")!=0 && strcmp(filter.os, laptops[index].os) !=0 )
			printLaptop = 0;

		if( strcmp(filter.processor,"")!=0 && strcmp(filter.processor, laptops[index].processor) !=0 )
			printLaptop = 0;

		if( strcmp(filter.gc,"")!=0 && strcmp(filter.gc, laptops[index].gc) !=0 )
			printLaptop = 0;
			
		if(filter.hd != 0 && filter.hd != laptops[index].hd)
			printLaptop =0; 
		
		if(filter.ram != 0 && filter.ram != laptops[index].ram)
			printLaptop =0; 
		
		if(filter.ssd != 0 && filter.ssd != laptops[index].ssd)
			printLaptop =0; 
		if(filter.battery_life != 0 && filter.battery_life != laptops[index].battery_life)
			printLaptop =0; 
		
		if(filter.size != 0 && filter.size != laptops[index].size)
			printLaptop =0;
						
		if(printLaptop) {
			filtered_laptops[count] = laptops[index];
			count++;
		}
	}
	debug("Filter Count: ",count);
	debug("Filtered Count: ", getFilteredLaptopCount(laptops, filter, total));
	printLaptopInfo(filtered_laptops, count);
}

int getFilteredLaptopCount(struct Laptop* laptops, struct Laptop filter, int total) {
	int index=0, count=0; 
	int printLaptop = 0;
	for(index; index<total; index++) {
		printLaptop = 1;
		
		if( strcmp(filter.purpose,"")!=0 && strcmp(filter.purpose, laptops[index].purpose) !=0 )
			printLaptop = 0;			

		if( strcmp(filter.company,"")!=0 && strcmp(filter.company, laptops[index].company) !=0 )
			printLaptop = 0;

		if( strcmp(filter.os,"")!=0 && strcmp(filter.os, laptops[index].os) !=0 )
			printLaptop = 0;

		if( strcmp(filter.processor,"")!=0 && strcmp(filter.processor, laptops[index].processor) !=0 )
			printLaptop = 0;

		if( strcmp(filter.gc,"")!=0 && strcmp(filter.gc, laptops[index].gc) !=0 )
			printLaptop = 0;
		
		if( filter.hd != 0 && filter.hd != laptops[index].hd)
			printLaptop = 0; 
			
		if(filter.ram != 0 && filter.ram != laptops[index].ram)
			printLaptop =0; 
		
		if(filter.ssd != 0 && filter.ssd != laptops[index].ssd)
			printLaptop =0; 
	
		if(filter.battery_life != 0 && filter.battery_life != laptops[index].battery_life)
			printLaptop =0; 
			
		if(filter.size != 0 && filter.size != laptops[index].size)
			printLaptop =0;
			
		if(printLaptop)
			count++;
	}
	return count;
}

void printLaptopInfo(struct Laptop* laptop, int count) {
	if( count==2 ){
		printf("\n\xc9\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcb\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcb\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xbb");
		printf("\n\xba PURPOSE:\t\xba %s      \t\xba %s      \t\xba",laptop[0].purpose, laptop[1].purpose);
		printf("\n\xcc\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xce\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xce\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xb9");
		printf("\n\xba BRAND:\t\xba %s \t\t\xba %s \t\t\xba",laptop[0].company, laptop[1].company);
		printf("\n\xcc\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xce\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xce\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xb9");
		printf("\n\xba OS:\t\t\xba %s \t\xba %s \t\xba",laptop[0].os,laptop[1].os);
		printf("\n\xcc\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xce\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xce\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xb9");
		printf("\n\xba SCREEN SIZE:\t\xba %d\"\t\t\xba %d\"\t\t\xba",laptop[0].size,laptop[1].size);
		printf("\n\xcc\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xce\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xce\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xb9");
		printf("\n\xba PROCESSOR:\t\xba %s  \t\xba %s  \t\xba",laptop[0].processor,laptop[1].processor);
		printf("\n\xcc\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xce\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xce\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xb9");
		printf("\n\xba HARD DRIVE:\t\xba %d GB\t\xba %d GB\t\xba",laptop[0].hd,laptop[1].hd);
		printf("\n\xcc\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xce\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xce\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xb9");
		printf("\n\xba RAM:\t\t\xba %d GB\t\t\xba %d GB\t\t\xba",laptop[0].ram,laptop[1].ram);
		printf("\n\xcc\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xce\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xce\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xb9");
		printf("\n\xba SSD:\t\t\xba %d %s    \t\xba %d %s    \t\xba",laptop[0].ssd, (laptop[0].ssd>0)?"GB":" ",laptop[1].ssd, (laptop[1].ssd>0)?"GB":" ");
		printf("\n\xcc\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xce\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xce\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xb9");
		printf("\n\xba GRAPHIC CARD:\t\xba %s\t\t\xba %s\t\t\xba",laptop[0].gc,laptop[1].gc);
		printf("\n\xcc\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xce\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xce\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xb9");
		printf("\n\xba BATTERY LIFE:\t\xba %d hrs  \t\xba %d hrs  \t\xba",laptop[0].battery_life,laptop[1].battery_life);
		printf("\n\xcc\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xce\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xce\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xb9");
		printf("\n\xba PRICE:\t\xba Rs. %d,000/-\t\xba Rs. %d,000/-\t\xba",laptop[0].price,laptop[1].price);
		printf("\n\xc8\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xca\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xca\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xbc");
	} else if( count==3 ){
		printf("\n\xc9\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcb\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcb\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcb\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xbb");
		printf("\n\xba PURPOSE:\t\xba %s      \t\xba %s      \t\xba %s      \t\xba",laptop[0].purpose, laptop[1].purpose, laptop[2].purpose);
		printf("\n\xcc\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xce\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xce\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xce\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xb9");
		printf("\n\xba BRAND:\t\xba %s \t\t\xba %s \t\t\xba %s \t\t\xba",laptop[0].company, laptop[1].company, laptop[2].company);
		printf("\n\xcc\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xce\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xce\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xce\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xb9");
		printf("\n\xba OS:\t\t\xba %s \t\xba %s \t\xba %s \t\xba",laptop[0].os,laptop[1].os,laptop[2].os);
		printf("\n\xcc\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xce\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xce\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xce\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xb9");
		printf("\n\xba SCREEN SIZE:\t\xba %d\"\t\t\xba %d\"\t\t\xba %d\"\t\t\xba",laptop[0].size,laptop[1].size, laptop[2].size);
		printf("\n\xcc\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xce\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xce\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xce\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xb9");
		printf("\n\xba PROCESSOR:\t\xba %s  \t\xba %s  \t\xba %s  \t\xba",laptop[0].processor,laptop[1].processor,laptop[2].processor);
		printf("\n\xcc\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xce\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xce\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xce\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xb9");
		printf("\n\xba HARD DRIVE:\t\xba %d GB\t\xba %d GB\t\xba %d GB\t\xba",laptop[0].hd,laptop[1].hd,laptop[2].hd);
		printf("\n\xcc\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xce\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xce\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xce\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xb9");
		printf("\n\xba RAM:\t\t\xba %d GB\t\t\xba %d GB\t\t\xba %d GB\t\t\xba",laptop[0].ram,laptop[1].ram,laptop[2].ram);
		printf("\n\xcc\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xce\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xce\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xce\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xb9");
		printf("\n\xba SSD:\t\t\xba %d %s    \t\xba %d %s    \t\xba %d %s    \t\xba",laptop[0].ssd, (laptop[0].ssd>0)?"GB":" ",laptop[1].ssd, (laptop[1].ssd>0)?"GB":" ",laptop[2].ssd, (laptop[2].ssd>0)?"GB":" ");
		printf("\n\xcc\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xce\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xce\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xce\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xb9");
		printf("\n\xba GRAPHIC CARD:\t\xba %s\t\t\xba %s\t\t\xba %s\t\t\xba",laptop[0].gc,laptop[1].gc,laptop[2].gc);
		printf("\n\xcc\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xce\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xce\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xce\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xb9");
		printf("\n\xba BATTERY LIFE:\t\xba %d hrs  \t\xba %d hrs  \t\xba %d hrs  \t\xba",laptop[0].battery_life,laptop[1].battery_life,laptop[2].battery_life);
		printf("\n\xcc\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xce\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xce\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xce\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xb9");
		printf("\n\xba PRICE:\t\xba Rs. %d,000/- \xba Rs. %d,000/- \xba Rs. %d,000/- \xba",laptop[0].price,laptop[1].price,laptop[2].price);
		printf("\n\xc8\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xca\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xca\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xca\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xbc");
	} else {
		for( count; count>0; count-- ) {
			printf("\n\xc9\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcb\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xbb");
			printf("\n\xba PURPOSE:\t\xba %s      \t\xba",laptop[count].purpose);
			printf("\n\xcc\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xce\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xb9");
			printf("\n\xba BRAND:\t\xba %s \t\t\xba",laptop[count].company);
			printf("\n\xcc\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xce\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xb9");
			printf("\n\xba OS:\t\t\xba %s \t\xba",laptop[count].os);
			printf("\n\xcc\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xce\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xb9");
			printf("\n\xba SCREEN SIZE:\t\xba %d\"\t\t\xba",laptop[count].size);
			printf("\n\xcc\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xce\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xb9");
			printf("\n\xba PROCESSOR:\t\xba %s\t\xba",laptop[count].processor);
			printf("\n\xcc\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xce\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xb9");
			printf("\n\xba HARD DRIVE:\t\xba %d GB\t\xba",laptop[count].hd);
			printf("\n\xcc\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xce\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xb9");
			printf("\n\xba RAM:\t\t\xba %d GB\t\t\xba",laptop[count].ram);
			printf("\n\xcc\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xce\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xb9");
			printf("\n\xba SSD:\t\t\xba %d %s    \t\xba",laptop[count].ssd, (laptop[count].ssd>0)?"GB":" ");
			printf("\n\xcc\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xce\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xb9");
			printf("\n\xba GRAPHIC CARD:\t\xba %s\t\t\xba",laptop[count].gc);
			printf("\n\xcc\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xce\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xb9");
			printf("\n\xba BATTERY LIFE:\t\xba %d hrs  \t\xba",laptop[count].battery_life);
			printf("\n\xcc\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xce\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xb9");
			printf("\n\xba PRICE:\t\xba Rs. %d,000/-\t\xba",laptop[count].price);
			printf("\n\xc8\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xca\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xbc");
		}
	}
}

int nextValue (FILE* db) {
  int value = 0;
  fscanf (db, "%d", &value);    
	return value;
}

char* getPurpose(int index) {
	char* purpose[4] = {"Game", "Program", "Office", "Home"};
	return purpose[index];
}

char* getCompany(int index) {
	char* company[4] = {"ASUS", "HP", "DELL", "APPLE"};
	return company[index];
}

char* getOS(int index) {
	char* os[4] = {"LINUX", "Windows 8", "Windows 10", "MAC"};
	return os[index];
}

char* getProcessor(int index) {
	char* processor[4] = {"Xeon", "Intel i5", "Intel i7", "Intel i9"};
	return processor[index];
}

int getHD(int index){
	int harddisk[2] = {500, 1000};
	return harddisk[index];
}

int getRAM(int index){
	int ram[3]= {2,4,8};
	return ram[index];
}

int getSSD(int index){
	int ssd[3]= {0,64,128};
	return ssd[index];
}

int getBT(int index){
	int bt[2]= {8,16};
	return bt[index];
}

int getSize(int index){
	int size[3]= {12,16,18};
	return size[index];
}

char* getGC(int index) {
	char* gc[2] = {"No", "Yes"};
	return gc[index];
}

void mainMenu(struct Laptop* laptops, struct Laptop filter, int db_size) {
	system("cls");
	printf("\n\n\t\t\tWelcome to Laptop Selector\n\nChoose an option from below:");
	printf("\t\t\t\t\xc9\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xbb");
	printf("\n1) Show all Laptops.\t\t\t\t\t\xba My Filter  \xba");
	printf("\n2) Filter Laptops by Purpose of use.");
	printf("\t\t\xc9\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xca\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcb\xcd\xcd\xcd\xcd\xca\xcd\xcd\xcd\xcd\xbb");
	printf("\n3) Filter Laptops by Brand.");
	printf("\t\t\t\xba Purpose \t\xba %s\t  \xba", (strcmp(filter.purpose, "")==0)?"Any":filter.purpose );
	printf("\n4) Filter Laptops by Operating System.");
	printf("\t\t\xcc\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xce\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xb9");
	printf("\n5) Filter Laptops by Processor.");
	printf("\t\t\t\xba Brand \t\xba %s\t  \xba", (strcmp(filter.company, "")==0)?"Any":filter.company );
	printf("\n6) Filter Laptops by Hard Disk.");
	printf("\t\t\t\xcc\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xce\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xb9");
	printf("\n7) Filter Laptops by Graphics Card.");
//	printf("\n---------------");
	printf("\t\t\xba OS \t\t\xba %s\t  \xba", (strcmp(filter.os, "")==0)?"Any":filter.os );
	//printf("\n0) Exit.");
	printf("\n13) Filter Laptops by RAM.");
	printf("\t\t\t\xcc\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xce\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xb9");
	printf("\n14) Filter Laptops by SSD.");
	printf("\t\t\t\xba Screen Size \t\xba %s\"\t  \xba", (filter.size==0)?"Any":toString(filter.size) );
	printf("\n15) Filter Laptops by Battery Life.");
	printf("\t\t\xcc\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xce\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xb9\n");
	printf("16) Filter Laptops by Screen Size");
	printf("\t\t\xba Processor \t\xba %s\t  \xba", (strcmp(filter.processor, "")==0)?"Any":filter.processor );
	printf("\n8) Clear Filter.");
	printf("\t\t\t\t\xcc\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xce\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xb9\n");
	printf("0) Exit.");
	printf("\t\t\t\t\t\xba Hard Disk \t\xba %s\t  \xba", (filter.hd==0)?"Any":toString(filter.hd) );
	printf("\t\t\t\t\t\t\t\xcc\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xce\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xb9\n");
	printf("\t\t\t\t\t\t\xba RAM \t\t\xba %s\t  \xba", (filter.ram==0)?"Any":toString(filter.ram) );
	printf("\t\t\t\t\t\t\t\xcc\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xce\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xb9\n");
	printf("\t\t\t\t\t\t\xba Graphic Card \t\xba %s\t  \xba", (strcmp(filter.gc, "")==0)?"Any":filter.gc );
	printf("\t\t\t\t\t\t\t\xcc\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xce\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xb9\n");
	printf("\t\t\t\t\t\t\xba Battery Life \t\xba %s\t  \xba", (filter.battery_life==0)?"Any":toString(filter.battery_life) );
	printf("\t\t\t\t\t\t\t\xcc\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xce\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xb9\n");
	printf("\t\t\t\t\t\t\xba SSD \t\t\xba %s\t  \xba", (filter.ssd==0)?"Any":toString(filter.ssd) );
	printf("\t\t\t\t\t\t\t\xcc\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xce\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xb9\n");
	printf("\t\t\t\t\t\t\xba Total \t\xba %d\t  \xba", getFilteredLaptopCount(laptops, filter, db_size) );
	printf("\t\t\t\t\t\t\t\xc8\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xca\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xbc\n");
}

void purposeMenu() {
	system("cls");
	printf("\n\n\t\t\tWelcome to Laptop Selector\n\t\tFiltering Laptops by Purpose of use\n\nChoose an option from below:");
	int index=0;
	for(index; index<4;)
		printf("\n%d) %s.",++index, getPurpose(index));
	printf("\n\n8) Any.");
	printf("\n------------------");
	printf("\n9) Back to Main Menu.\n\n");	
	printf("\n0) Exit.\n\n");
}

void companyMenu() {
	system("cls");
	printf("\n\n\t\t\tWelcome to Laptop Selector\n\t\tFiltering Laptops by Company Name\n\nChoose an option from below:");
	int index=0;
	for(index; index<4;)
		printf("\n%d) %s.",++index, getCompany(index));
	printf("\n\n8) Any.");
	printf("\n------------------");
	printf("\n9) Back to Main Menu.\n\n");	
	printf("\n0) Exit.\n\n");
}

void osMenu() {
	system("cls");
	printf("\n\n\t\t\tWelcome to Laptop Selector\n\t\tFiltering Laptops by Operating System\n\nChoose an option from below:");
	int index=0;
	for(index; index<4;)
		printf("\n%d) %s.",++index, getOS(index));
	printf("\n\n8) Any.");
	printf("\n------------------");
	printf("\n9) Back to Main Menu.\n\n");	
	printf("\n0) Exit.\n\n");
}

void processorMenu() {
	system("cls");
	printf("\n\n\t\t\tWelcome to Laptop Selector\n\t\tFiltering Laptops by Processor.\n\nChoose an option from below:");
	int index=0;
	for(index; index<4;)
		printf("\n%d) %s.",++index, getProcessor(index));
	printf("\n\n8) Any.");
	printf("\n------------------");

	printf("\n9) Back to Main Menu.\n\n");	
	printf("\n0) Exit.\n\n");
}

void hdMenu(){
	system("cls");
	printf("\n\n\t\t\tWelcome to Laptop Selector\n\t\tFiltering Laptops by Hard Disk.\n\nChoose an option from below:");
	int index=0;
	for(index; index<2;)
		printf("\n%d) %d GB.", ++index, getHD(index));
	printf("\n\n8) Any.");
	printf("\n------------------");

	printf("\n9) Back to Main Menu.\n\n");	
	printf("\n0) Exit.\n\n");	
}

void ramMenu(){
	system("cls");
	printf("\n\n\t\t\tWelcome to Laptop Selector\n\t\tFiltering Laptops by RAM.\n\nChoose an option from below:");
	int index=0;
	for(index; index<3;)
		printf("\n%d) %d GB.", ++index, getRAM(index));
	printf("\n\n8) Any.");
	printf("\n------------------");

	printf("\n9) Back to Main Menu.\n\n");	
	printf("\n0) Exit.\n\n");
}

void ssdMenu(){
	system("cls");
	printf("\n\n\t\t\tWelcome to Laptop Selector\n\t\tFiltering Laptops by SSD.\n\nChoose an option from below:");
	int index=0;
	for(index; index<3;)
		printf("\n%d) %d GB.", ++index, getSSD(index));
	printf("\n\n8) Any.");
	printf("\n------------------");

	printf("\n9) Back to Main Menu.\n\n");	
	printf("\n0) Exit.\n\n");
}

void btMenu(){
	system("cls");
	printf("\n\n\t\t\tWelcome to Laptop Selector\n\t\tFiltering Laptops by Battery Life.\n\nChoose an option from below:");
	int index=0;
	for(index; index<2;)
		printf("\n%d) %d Hours.", ++index, getBT(index));
	printf("\n\n8) Any.");
	printf("\n------------------");

	printf("\n9) Back to Main Menu.\n\n");	
	printf("\n0) Exit.\n\n");
}


void sizeMenu(){
	system("cls");
	printf("\n\n\t\t\tWelcome to Laptop Selector\n\t\tFiltering Laptops by Screen Size.\n\nChoose an option from below:");
	int index=0;
	for(index; index<3;)
		printf("\n%d) %d Hours.", ++index, getSize(index));
	printf("\n\n8) Any.");
	printf("\n------------------");
	
	printf("\n9) Back to Main Menu.\n\n");	
	printf("\n0) Exit.\n\n");
}


void gcMenu() {
	system("cls");
	printf("\n\n\t\t\tWelcome to Laptop Selector\n\t\tFiltering Laptops by Graphic Card.\n\nChoose an option from below:");
	printf("\n1) Without Graphic Card.");
	printf("\n2) With Graphic Card.");
	printf("\n\n8) Any.");
	printf("\n------------------");
	printf("\n9) Back to Main Menu.\n\n");	
	printf("\n0) Exit.\n\n");
}

void invalidUserInput() {
	system("cls");
	printf("\n\n\n\n\n\t\tNot a valid Input...");
	getch();
}

char* toString(int value) {
	char int_string[10];
	itoa(value, int_string, 10);
	return int_string;
}

void debug(char* msg, int num) {
	printf("\n\t\t%s%d\n", msg, num);
}
