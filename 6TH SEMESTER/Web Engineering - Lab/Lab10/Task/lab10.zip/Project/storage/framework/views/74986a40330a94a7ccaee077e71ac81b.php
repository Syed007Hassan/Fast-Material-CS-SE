<!DOCTYPE html>
<html>

<head>
    <title>Laravel 10 CRUD Application</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>

    <div class="container">
        <?php echo $__env->yieldContent('content'); ?>
    </div>

</body>

</html>
<?php /**PATH F:\6th Sem Content\Web Engineering - Lab\Lab10\Task\Project\resources\views/products/layout.blade.php ENDPATH**/ ?>