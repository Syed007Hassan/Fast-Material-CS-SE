var Name = "HP PAVILION";
let series = "15";
year = 2020;

const product = {
  Name: Name,
  series: series,
  year: year,
};

console.log(product);
