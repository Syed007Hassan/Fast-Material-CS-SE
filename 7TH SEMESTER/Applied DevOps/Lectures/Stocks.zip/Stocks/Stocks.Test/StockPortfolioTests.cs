﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Stocks.Test
{
    [TestClass]
    public class StockPortfolioTests
    {
        [TestMethod]
        public void ComputesLowestPrice()
        {
            StockPortfolio portfolio = new StockPortfolio();

            portfolio.AddStock(100);
            portfolio.AddStock(25);

            StockStatistics result = portfolio.ComputeStatistics();

            Assert.AreEqual(25, result.LowestStock);
        }
    }
}